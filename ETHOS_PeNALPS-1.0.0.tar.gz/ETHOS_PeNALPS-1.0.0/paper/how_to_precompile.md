docker run --rm --volume %cd%/paper:/data --env JOURNAL=joss openjournals/inara
Image Name: openjournals/inara
Volume path: Needs to be adjusted between windows and linux