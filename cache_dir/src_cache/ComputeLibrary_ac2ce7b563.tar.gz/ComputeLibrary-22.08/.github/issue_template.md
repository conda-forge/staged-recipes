<!--
Please fill the fields below in order to help us diagnose the issue. If you have a
general question or a problem with the scripts, you can ignore these fields.
-->

**Output of 'strings libarm_compute.so | grep arm_compute_version':**

**Platform:**

**Operating System:**


<!--
Please describe the issue (error, expected behaviour etc) and steps to reproduce it. If possible,
share the shortest code necessary that reproduces the issue.
-->

**Problem description:**
