# assets

You need to copy the following files to this folder.

- `$WORK_DIR/openvino_install/runtime/lib/aarch64/plugins.xml`
- `$WORK_DIR/open_model_zoo/tools/downloader/intel/ssdlite_mobilenet_v2/FP16/ssdlite_mobilenet_v2.xml`
- `$WORK_DIR/open_model_zoo/tools/downloader/intel/ssdlite_mobilenet_v2/FP16/ssdlite_mobilenet_v2.bin`