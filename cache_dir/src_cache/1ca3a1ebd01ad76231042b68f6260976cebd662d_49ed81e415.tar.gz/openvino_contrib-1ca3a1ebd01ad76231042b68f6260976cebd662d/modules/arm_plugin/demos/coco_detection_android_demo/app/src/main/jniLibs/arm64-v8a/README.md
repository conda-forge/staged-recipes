# arm64-v8a

You need to copy the following files to this folder (for Java API 2.0).

- `libc++_shared.so`
- `libinference_engine_java_api.so`
- `libopenvino.so`
- `libopenvino_arm_cpu_plugin.so`
- `libopenvino_auto_batch_plugin.so`
- `libopenvino_auto_plugin.so`
- `libopenvino_c.so`
- `libopenvino_gapi_preproc.so`
- `libopenvino_hetero_plugin.so`
- `libopenvino_ir_frontend.so`
- `libopenvino_onnx_frontend.so`
- `libopenvino_paddle_frontend.so`
- `libopenvino_tensorflow_fe.so`