# libs

You need to copy the following files to this folder.

- `~/android_ov/openvino/bin/aarch64/Release/lib/inference_engine_java_api.jar`