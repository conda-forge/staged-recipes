# OpenVINO Debug Capabilities

OpenVINO components provides different debug capabilities, to get more infromation please read:

* [OpenVINO Model Debug Capabilities](https://docs.openvino.ai/latest/openvino_docs_OV_UG_Model_Representation.html#model-debug-capabilities)
* [OpenVINO Pass Manager Debug Capabilities](#todo)

## See also
 * [OpenVINO™ README](../../README.md)
 * [Developer documentation](../../docs/dev/index.md)
