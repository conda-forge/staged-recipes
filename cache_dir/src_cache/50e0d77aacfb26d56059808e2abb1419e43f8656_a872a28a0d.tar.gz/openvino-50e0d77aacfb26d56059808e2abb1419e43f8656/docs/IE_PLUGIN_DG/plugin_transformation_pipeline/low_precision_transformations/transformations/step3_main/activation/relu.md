# ReluTransformation transformation {#openvino_docs_OV_UG_lpt_ReluTransformation}

ngraph::pass::low_precision::ReluTransformation class represents the `Relu` operation transformation.
