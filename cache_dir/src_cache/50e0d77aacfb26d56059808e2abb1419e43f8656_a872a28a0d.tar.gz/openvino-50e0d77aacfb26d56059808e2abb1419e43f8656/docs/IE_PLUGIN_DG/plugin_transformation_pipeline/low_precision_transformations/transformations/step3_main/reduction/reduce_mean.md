# ReduceMeanTransformation transformation {#openvino_docs_OV_UG_lpt_ReduceMeanTransformation}

ngraph::pass::low_precision::ReduceMeanTransformation class represents the `ReduceMean` operation transformation.
