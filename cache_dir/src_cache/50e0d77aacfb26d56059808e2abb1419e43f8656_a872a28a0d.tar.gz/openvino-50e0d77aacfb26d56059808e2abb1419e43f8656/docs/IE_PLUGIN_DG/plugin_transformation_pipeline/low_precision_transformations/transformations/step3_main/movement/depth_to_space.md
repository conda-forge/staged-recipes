# DepthToSpaceTransformation transformation {#openvino_docs_OV_UG_lpt_DepthToSpaceTransformation}

ngraph::pass::low_precision::DepthToSpaceTransformation class represents the `DepthToSpace` operation transformation.
