# FoldConvertTransformation transformation {#openvino_docs_OV_UG_lpt_FoldConvertTransformation}

ngraph::pass::low_precision::FoldConvertTransformation class represents the `FoldConvertTransformation` transformation.
