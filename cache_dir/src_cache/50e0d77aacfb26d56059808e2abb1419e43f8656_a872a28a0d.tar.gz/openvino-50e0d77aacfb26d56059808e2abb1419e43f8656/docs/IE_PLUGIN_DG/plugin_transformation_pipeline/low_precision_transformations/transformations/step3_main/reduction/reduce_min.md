# ReduceMinTransformation transformation {#openvino_docs_OV_UG_lpt_ReduceMinTransformation}

ngraph::pass::low_precision::ReduceMinTransformation class represents the `ReduceMin` operation transformation.
