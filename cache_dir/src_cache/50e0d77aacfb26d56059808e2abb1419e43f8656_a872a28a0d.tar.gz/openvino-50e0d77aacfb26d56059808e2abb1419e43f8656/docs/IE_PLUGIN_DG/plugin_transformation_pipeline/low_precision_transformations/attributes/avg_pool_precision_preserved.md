# AvgPoolPrecisionPreserved attribute {#openvino_docs_OV_UG_lpt_AvgPoolPrecisionPreserved}

ngraph::AvgPoolPrecisionPreservedAttribute class represents the `AvgPoolPrecisionPreserved` attribute.

Utility attribute, which is used only during `AvgPool` operation, precision preserved property definition. 

| Property name | Values                                       |
|---------------|----------------------------------------------|
| Required      | Yes                                          |
| Defined       | Operation                                    |
| Properties    | value (boolean)                              |