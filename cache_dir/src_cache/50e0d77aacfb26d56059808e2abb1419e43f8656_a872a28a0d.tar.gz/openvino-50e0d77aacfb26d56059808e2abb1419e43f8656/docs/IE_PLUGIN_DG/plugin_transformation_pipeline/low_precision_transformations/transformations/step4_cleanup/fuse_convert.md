# FuseConvertTransformation transformation {#openvino_docs_OV_UG_lpt_FuseConvertTransformation}

ngraph::pass::low_precision::FuseConvertTransformation class represents the `FuseConvertTransformation` transformation.
