# ReduceMaxTransformation transformation {#openvino_docs_OV_UG_lpt_ReduceMaxTransformation}

ngraph::pass::low_precision::ReduceMaxTransformation class represents the `ReduceMax` operation transformation.
