# InterpolateTransformation transformation {#openvino_docs_OV_UG_lpt_InterpolateTransformation}

ngraph::pass::low_precision::InterpolateTransformation class represents the `Interpolate` operation transformation.
