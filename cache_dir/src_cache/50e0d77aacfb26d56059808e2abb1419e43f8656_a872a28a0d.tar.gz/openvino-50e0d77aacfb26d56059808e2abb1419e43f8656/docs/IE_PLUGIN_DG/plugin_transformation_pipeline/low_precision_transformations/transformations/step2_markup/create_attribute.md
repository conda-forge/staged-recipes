# CreateAttribute transformation {#openvino_docs_OV_UG_lpt_CreateAttribute}

ngraph::pass::low_precision::CreateAttribute class represents the `CreateAttribute` transformation.