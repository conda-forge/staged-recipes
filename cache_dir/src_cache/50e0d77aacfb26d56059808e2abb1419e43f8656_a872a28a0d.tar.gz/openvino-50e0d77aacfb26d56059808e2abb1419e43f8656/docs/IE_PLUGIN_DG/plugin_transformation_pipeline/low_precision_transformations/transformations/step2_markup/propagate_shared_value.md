# PropagateSharedValue transformation {#openvino_docs_OV_UG_lpt_PropagateSharedValue}

ngraph::pass::low_precision::PropagateSharedValue class represents the `PropagateSharedValue` transformation.
