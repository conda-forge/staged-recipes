# TransposeTransformation transformation {#openvino_docs_OV_UG_lpt_TransposeTransformation}

ngraph::pass::low_precision::TransposeTransformation class represents the `Transpose` operation transformation.
