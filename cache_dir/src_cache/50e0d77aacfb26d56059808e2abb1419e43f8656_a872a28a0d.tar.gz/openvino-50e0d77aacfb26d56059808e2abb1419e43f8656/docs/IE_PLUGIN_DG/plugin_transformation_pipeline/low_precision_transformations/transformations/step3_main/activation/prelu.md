# PReluTransformation transformation {#openvino_docs_OV_UG_lpt_PReluTransformation}

ngraph::pass::low_precision::PReluTransformation class represents the `PRelu` operation transformation.
