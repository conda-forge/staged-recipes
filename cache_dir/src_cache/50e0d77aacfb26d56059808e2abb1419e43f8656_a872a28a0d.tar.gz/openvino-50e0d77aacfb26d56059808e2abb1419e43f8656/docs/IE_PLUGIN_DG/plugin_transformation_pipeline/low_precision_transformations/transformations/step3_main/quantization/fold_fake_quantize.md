# FoldFakeQuantizeTransformation transformation {#openvino_docs_OV_UG_lpt_FoldFakeQuantizeTransformation}

ngraph::pass::low_precision::FoldFakeQuantizeTransformation class represents the `FoldFakeQuantize` operation transformation.
