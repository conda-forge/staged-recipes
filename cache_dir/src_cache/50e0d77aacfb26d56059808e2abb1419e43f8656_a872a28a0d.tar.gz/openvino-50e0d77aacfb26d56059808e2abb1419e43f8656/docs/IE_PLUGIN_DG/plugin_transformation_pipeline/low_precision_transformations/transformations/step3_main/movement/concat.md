# ConcatTransformation transformation {#openvino_docs_OV_UG_lpt_ConcatTransformation}

ngraph::pass::low_precision::ConcatTransformation class represents the `Concat` operation transformation.
