# ShuffleChannelsTransformation transformation {#openvino_docs_OV_UG_lpt_ShuffleChannelsTransformation}

ngraph::pass::low_precision::ShuffleChannelsTransformation class represents the `ShuffleChannels` operation transformation.
