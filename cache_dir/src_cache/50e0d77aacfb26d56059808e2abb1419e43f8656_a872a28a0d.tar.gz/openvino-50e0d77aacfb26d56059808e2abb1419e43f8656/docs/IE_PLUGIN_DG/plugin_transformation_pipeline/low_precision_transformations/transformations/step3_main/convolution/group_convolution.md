# GroupConvolutionTransformation transformation {#openvino_docs_OV_UG_lpt_GroupConvolutionTransformation}

ngraph::pass::low_precision::GroupConvolutionTransformation class represents the `GroupConvolution` operation transformation.
