# NormalizeL2Transformation transformation {#openvino_docs_OV_UG_lpt_NormalizeL2Transformation}

ngraph::pass::low_precision::NormalizeL2Transformation class represents the `NormalizeL2` operation transformation.
