# ClampTransformation transformation {#openvino_docs_OV_UG_lpt_ClampTransformation}

ngraph::pass::low_precision::ClampTransformation class represents the `Clamp` operation transformation.
