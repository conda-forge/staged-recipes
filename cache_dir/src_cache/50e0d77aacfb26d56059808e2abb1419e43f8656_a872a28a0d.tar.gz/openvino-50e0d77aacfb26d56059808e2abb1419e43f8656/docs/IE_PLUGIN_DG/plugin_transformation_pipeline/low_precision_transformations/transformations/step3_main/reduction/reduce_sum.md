# ReduceSumTransformation transformation {#openvino_docs_OV_UG_lpt_ReduceSumTransformation}

ngraph::pass::low_precision::ReduceSumTransformation class represents the `ReduceSum` operation transformation.
