# MaxPoolTransformation transformation {#openvino_docs_OV_UG_lpt_MaxPoolTransformation}

ngraph::pass::low_precision::MaxPoolTransformation class represents the `MaxPool` operation transformation.
