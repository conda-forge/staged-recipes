# UnsqueezeTransformation transformation {#openvino_docs_OV_UG_lpt_UnsqueezeTransformation}

ngraph::pass::low_precision::UnsqueezeTransformation class represents the `Unsqueeze` operation transformation.
