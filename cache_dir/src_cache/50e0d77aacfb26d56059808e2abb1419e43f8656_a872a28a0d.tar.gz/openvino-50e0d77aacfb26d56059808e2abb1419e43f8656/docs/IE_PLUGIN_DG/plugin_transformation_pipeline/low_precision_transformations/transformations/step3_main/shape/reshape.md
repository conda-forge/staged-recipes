# ReshapeTransformation transformation {#openvino_docs_OV_UG_lpt_ReshapeTransformation}

ngraph::pass::low_precision::ReshapeTransformation class represents the `Reshape` operation transformation.
