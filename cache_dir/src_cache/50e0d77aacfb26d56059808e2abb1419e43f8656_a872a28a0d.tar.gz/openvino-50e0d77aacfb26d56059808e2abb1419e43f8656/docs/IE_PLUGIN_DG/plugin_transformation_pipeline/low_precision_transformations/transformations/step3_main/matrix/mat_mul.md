# MatMulTransformation transformation {#openvino_docs_OV_UG_lpt_MatMulTransformation}

ngraph::pass::low_precision::MatMulTransformation class represents the `MatMul` operation transformation.
