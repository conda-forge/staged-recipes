# AvgPoolTransformation transformation {#openvino_docs_OV_UG_lpt_AvgPoolTransformation}

ngraph::pass::low_precision::AvgPoolTransformation class represents the `AvgPool` operation transformation.
