# PadTransformation transformation {#openvino_docs_OV_UG_lpt_PadTransformation}

ngraph::pass::low_precision::PadTransformation class represents the `Pad` operation transformation.
