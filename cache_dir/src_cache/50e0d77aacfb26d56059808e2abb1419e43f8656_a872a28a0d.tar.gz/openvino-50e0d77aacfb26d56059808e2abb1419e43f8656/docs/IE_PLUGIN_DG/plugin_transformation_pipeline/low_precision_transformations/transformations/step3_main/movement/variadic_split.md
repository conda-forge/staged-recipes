# VariadicSplitTransformation transformation {#openvino_docs_OV_UG_lpt_VariadicSplitTransformation}

ngraph::pass::low_precision::VariadicSplitTransformation class represents the `VariadicSplit` operation transformation.
