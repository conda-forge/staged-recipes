# LinOpSequenceFusion transformation {#openvino_docs_OV_UG_lpt_LinOpSequenceFusion}

ngraph::pass::LinOpSequenceFusion class represents the `LinOpSequenceFusion` transformation.

`LinOpSequenceFusion` is common nGraph transformation.
