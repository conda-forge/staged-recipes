# MultiplyTransformation transformation {#openvino_docs_OV_UG_lpt_MultiplyTransformation}

ngraph::pass::low_precision::MultiplyTransformation class represents the `Multiply` operation transformation.