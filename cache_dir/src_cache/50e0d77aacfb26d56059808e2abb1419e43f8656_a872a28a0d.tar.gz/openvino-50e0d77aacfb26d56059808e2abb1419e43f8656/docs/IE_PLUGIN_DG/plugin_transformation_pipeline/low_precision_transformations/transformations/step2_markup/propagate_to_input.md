# PropagateToInput transformation {#openvino_docs_OV_UG_lpt_PropagateToInput}

ngraph::pass::low_precision::PropagateToInput class represents the `PropagateToInput` transformation.
