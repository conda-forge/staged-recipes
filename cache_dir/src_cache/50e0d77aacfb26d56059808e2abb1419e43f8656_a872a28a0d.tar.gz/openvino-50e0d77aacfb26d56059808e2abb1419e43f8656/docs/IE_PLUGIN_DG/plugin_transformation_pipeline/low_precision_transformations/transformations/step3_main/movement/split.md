# SplitTransformation transformation {#openvino_docs_OV_UG_lpt_SplitTransformation}

ngraph::pass::low_precision::SplitTransformation class represents the `Split` operation transformation.
