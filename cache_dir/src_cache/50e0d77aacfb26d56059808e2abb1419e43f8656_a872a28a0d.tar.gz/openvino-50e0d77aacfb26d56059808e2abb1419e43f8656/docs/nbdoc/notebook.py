class Notebook:
    def __init__(self, name, path):
        self.name = name
        self.path = path
