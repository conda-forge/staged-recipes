class Section:
    def __init__(self, name: str, notebooks: list):
        self.name = name
        self.notebooks = notebooks
