OpenVINO Python API - Compatibility
===================================

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst

   openvino.inference_engine

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst

   ngraph

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst

   _pyngraph
