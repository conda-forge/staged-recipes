This directory contains the inference results for various models reported in the paper on DotPrompts.

The files in this directory are stored in [git lfs](https://git-lfs.com/). If after cloning, this directory doesn't contain files `dotprompts_results.csv` and `dotprompts_results_sample.csv`, then setup git-lfs from the above reference, and clone the repository again.
