=========
blop
=========

.. image:: https://github.com/NSLS-II/blop/actions/workflows/testing.yml/badge.svg
   :target: https://github.com/NSLS-II/blop/actions/workflows/testing.yml


.. image:: https://img.shields.io/pypi/v/blop.svg
        :target: https://pypi.python.org/pypi/blop

.. image:: https://img.shields.io/conda/vn/conda-forge/blop.svg
        :target: https://anaconda.org/conda-forge/blop

Beamline Optimization Tools

* Free software: 3-clause BSD license
* Documentation: https://NSLS-II.github.io/blop.
