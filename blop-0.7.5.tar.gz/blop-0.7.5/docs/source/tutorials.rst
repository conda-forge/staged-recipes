Tutorials
=========

.. toctree::
   :maxdepth: 2

   tutorials/introduction.ipynb
   tutorials/hyperparameters.ipynb
   tutorials/pareto-fronts.ipynb
   tutorials/passive-dofs.ipynb
   tutorials/kb-mirrors.ipynb
   tutorials/xrt-blop-demo.ipynb
   tutorials/ax-blop-demo.ipynb
