# `tools`

Helper utility to manage global tool installations.

* [`install`](install.md): installs a tool globally.

* [`uninstall`](uninstall.md): uninstalls a globally installed tool.

* [`list`](list.md): lists all globally installed tools.
