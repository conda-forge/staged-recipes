# `self`

Command to manage Rye itself.

* [`completion`](completion.md): Generates a completion script for Rye.

* [`update`](update.md): Performs an update of Rye.

* [`uninstall`](uninstall.md): Uninstalls Rye again.
