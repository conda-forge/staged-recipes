# Notes

This folder contains various thoughts and notes about Python packaging.

* [Meta Server](metasrv.md): why a meta data server should exist.