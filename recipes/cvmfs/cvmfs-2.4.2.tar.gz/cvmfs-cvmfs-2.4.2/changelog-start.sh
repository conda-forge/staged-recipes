#!/bin/sh

git checkout -b fix-changelog

