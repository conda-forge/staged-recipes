#!/bin/sh

# there is nothing to configure for pacparser
