#!/bin/sh

# there is nothing to configure for python-geoip
