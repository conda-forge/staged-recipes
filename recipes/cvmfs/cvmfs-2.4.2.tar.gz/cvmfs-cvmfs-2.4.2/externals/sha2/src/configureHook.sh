#!/bin/sh

# there is nothing to configure for sha2.
