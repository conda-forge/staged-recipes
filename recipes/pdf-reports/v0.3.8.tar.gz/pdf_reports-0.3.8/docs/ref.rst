.. _reference:

PDF Reports Reference manual
============================

Core functions
~~~~~~~~~~~~~~

.. automodule:: pdf_reports.pdf_reports
   :members:

Tools
~~~~~

.. automodule:: pdf_reports.tools
   :members:
