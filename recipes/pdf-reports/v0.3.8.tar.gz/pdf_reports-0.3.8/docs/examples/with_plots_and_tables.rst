.. non_unique_kmers_minimization:

Report with plots and tables
----------------------------

Python code
~~~~~~~~~~~

.. literalinclude:: ../../examples/example_with_plot_and_tables/with_plots_and_tables.py

Pug template
~~~~~~~~~~~~

.. literalinclude:: ../../examples/example_with_plot_and_tables/with_plots_and_tables.pug

Result
~~~~~~

`PDF link <https://github.com/Edinburgh-Genome-Foundry/pdf_reports/raw/master/examples/example_with_plot_and_tables/with_plots_and_tables.pdf>`_

.. raw:: html

    <center>
    <object width=600 height=800 data="https://github.com/Edinburgh-Genome-Foundry/pdf_reports/raw/master/examples/example_with_plot_and_tables/with_plots_and_tables.pdf" type="application/pdf">
    <iframe width=600 height=800 src="https://docs.google.com/viewer?url=https://github.com/Edinburgh-Genome-Foundry/pdf_reports/raw/master/examples/example_with_plot_and_tables/with_plots_and_tables.pdf&embedded=true"></iframe>
    </object>
    </center>
