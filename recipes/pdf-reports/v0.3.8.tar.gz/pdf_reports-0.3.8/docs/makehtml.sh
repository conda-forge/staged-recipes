make html
firefox ../../built_docs/html/index.html
