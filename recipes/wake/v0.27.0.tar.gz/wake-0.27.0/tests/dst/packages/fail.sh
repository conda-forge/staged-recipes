#! /bin/sh

"${1:-wake}" --in foo -q test
