#! /bin/sh

"${1:-wake}" -q test
