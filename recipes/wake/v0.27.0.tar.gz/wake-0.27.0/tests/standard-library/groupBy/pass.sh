#! /bin/sh

"${1:-wake}" --stdout=warning,report test
