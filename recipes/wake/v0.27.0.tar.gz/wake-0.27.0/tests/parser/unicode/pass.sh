#! /bin/sh

"${1:-wake}" test
