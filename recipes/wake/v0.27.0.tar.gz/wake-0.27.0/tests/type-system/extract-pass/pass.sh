#! /bin/sh

"${1:-wake}" -v test
