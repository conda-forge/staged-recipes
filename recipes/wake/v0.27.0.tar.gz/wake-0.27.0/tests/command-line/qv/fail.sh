#! /bin/sh

"${1:-wake}" -qv -x Unit
