## v. 1.0 - 2019-08-18
 - Added version number
 - Added .travis.yml for continuous integration
 - Improved documentation and error messages
 - Minor fixes

## v. 0.9 - 2019-04-21
 - Pre-release: working prototype
