# pysam versioning information
__version__ = "0.23.3"

__samtools_version__ = "1.21"
__bcftools_version__ = "1.21"
__htslib_version__ = "1.21"
