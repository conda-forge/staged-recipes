==========================
MySQL Connector/Python 2.2
==========================

MySQL Connector/Python
Copyright (c) 2009, 2016, Oracle and/or its affiliates. All rights reserved.

License information can be found in the LICENSE.txt file.


Requirements
============

Python Protobuf (version >= 3.0.0)
https://developers.google.com/protocol-buffers/docs/downloads


Documentation & Examples
========================

Documentation for all Connector/Python versions can be found online here:

 http://dev.mysql.com/doc/connector-python/en/index.html

The source distribution of Connector/Python also contains example scripts.
They can be found in the examples/ directory.


License
=======

This is a release of MySQL Connector/Python, Oracle's dual-
license Python Driver for MySQL. For the avoidance of
doubt, this particular copy of the software is released
under the version 2 of the GNU General Public License.
MySQL Connector/Python is brought to you by Oracle.

Copyright (c) 2011, 2016, Oracle and/or its affiliates. All rights reserved.

License information can be found in the LICENSE.txt file.

MySQL FOSS License Exception
We want free and open source software applications under 
certain licenses to be able to use the GPL-licensed MySQL 
Connector/Python (specified GPL-licensed MySQL client libraries)
despite the fact that not all such FOSS licenses are 
compatible with version 2 of the GNU General Public License.
Therefore there are special exceptions to the terms and
conditions of the GPLv2 as applied to these client libraries, 
which are identified and described in more detail in the 
FOSS License Exception at
<http://www.mysql.com/about/legal/licensing/foss-exception.html>

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This distribution may include materials developed by third
parties. For license and attribution notices for these
materials, please refer to the documentation that accompanies
this distribution (see the "Licenses for Third-Party Components"
appendix) or view the online documentation at 
<http://dev.mysql.com/doc/>
A copy of the license/notices is also reproduced below.

GPLv2 Disclaimer
For the avoidance of doubt, except that if any license choice
other than GPL or LGPL is available it will apply instead, 
Oracle elects to use only the General Public License version 2 
(GPLv2) at this time for any software where a choice of GPL 
license versions is made available with the language indicating 
that GPLv2 or any later version may be used, or where a choice 
of which version of the GPL is applied is otherwise unspecified.

