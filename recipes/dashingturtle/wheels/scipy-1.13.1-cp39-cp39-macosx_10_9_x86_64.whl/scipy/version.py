# THIS FILE IS GENERATED DURING THE SCIPY BUILD
# See tools/version_utils.py for details

short_version = '1.13.1'
version = '1.13.1'
full_version = '1.13.1'
git_revision = '44e4eba'
commit_count = '1634'
release = True

if not release:
    version = full_version
