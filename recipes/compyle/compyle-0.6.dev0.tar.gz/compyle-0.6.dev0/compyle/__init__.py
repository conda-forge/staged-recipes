# See PEP 440 for more on suitable version numbers.
__version__ = '0.6.dev0'
