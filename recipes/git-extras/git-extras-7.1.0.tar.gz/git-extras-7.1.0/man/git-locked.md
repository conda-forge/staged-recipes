git-locked(1) -- ls files that have been locked
========================================================

## SYNOPSIS

`git-locked`

## DESCRIPTION

  List local files that have been locked

## EXAMPLES

    $ git lock config/database.yml
    $ git locked
    config/database.yml

## AUTHOR

Written by Kevin Woo &lt;<kevinawoo@gmail.com>&gt;

## REPORTING BUGS

&lt;<https://github.com/tj/git-extras/issues>&gt;

## SEE ALSO

&lt;<https://github.com/tj/git-extras>&gt;
