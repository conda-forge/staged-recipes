git-show-unmerged-branches(1) -- Show unmerged branches
=======================================================

## SYNOPSIS

`git-show-unmerged-branches`

## DESCRIPTION

  Show all branches not merged in to current HEAD.

## EXAMPLES

    $ git show-unmerged-branches

## AUTHOR

Written by Paul Schreiber &lt;<paulschreiber@gmail.com>&gt;

## REPORTING BUGS

&lt;<https://github.com/tj/git-extras/issues>&gt;

## SEE ALSO

&lt;<https://github.com/tj/git-extras>&gt;
