<NAME>(1) -- <short description>
================================

## SYNOPSIS

`<NAME>` [OPTIONS]

## DESCRIPTION

## OPTIONS

## EXAMPLES

## AUTHOR

Written by <AUTHOR> <EMAIL> [and <SECOND_AUTHOR> <EMAIL>]

## REPORTING BUGS

&lt;<https://github.com/tj/git-extras/issues>&gt;

## SEE ALSO

&lt;<https://github.com/tj/git-extras>&gt;
