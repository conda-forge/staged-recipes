git-show-merged-branches(1) -- Show merged branches
===================================================

## SYNOPSIS

`git-show-merged-branches`

## DESCRIPTION

  Show all branches merged in to current HEAD.

## EXAMPLES

    $ git show-merged-branches

## AUTHOR

Written by Paul Schreiber &lt;<paulschreiber@gmail.com>&gt;

## REPORTING BUGS

&lt;<https://github.com/tj/git-extras/issues>&gt;

## SEE ALSO

&lt;<https://github.com/tj/git-extras>&gt;
