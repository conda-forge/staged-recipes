/* $Id: ReconstructedVirtualGeomagneticPole.cc 8651 2010-06-06 18:15:55Z jcannon $ */
 
/**
 * \file 
 * $Revision: 8651 $
 * $Date: 2010-06-07 04:15:55 +1000 (Mon, 07 Jun 2010) $
 * 
 * Copyright (C) 2010 The University of Sydney, Australia
 *
 * This file is part of GPlates.
 *
 * GPlates is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, version 2, as published by
 * the Free Software Foundation.
 *
 * GPlates is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "ReconstructedVirtualGeomagneticPole.h"

#include "ReconstructionGeometryVisitor.h"

#include "model/WeakObserverVisitor.h"


void
GPlatesAppLogic::ReconstructedVirtualGeomagneticPole::accept_visitor(
		ConstReconstructionGeometryVisitor &visitor) const
{
	visitor.visit(GPlatesUtils::get_non_null_pointer(this));
}


void
GPlatesAppLogic::ReconstructedVirtualGeomagneticPole::accept_visitor(
		ReconstructionGeometryVisitor &visitor)
{
	visitor.visit(GPlatesUtils::get_non_null_pointer(this));
}


void
GPlatesAppLogic::ReconstructedVirtualGeomagneticPole::accept_weak_observer_visitor(
		GPlatesModel::WeakObserverVisitor<GPlatesModel::FeatureHandle> &visitor)
{
	visitor.visit_reconstructed_virtual_geomagnetic_pole(*this);
}
