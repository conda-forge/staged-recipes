"""
=========
GPlates
=========

Widgets for GPlates Data Mining.

Needed for Orange 2.7

"""

# Category description for the widget registry

NAME = "GPlates"

DESCRIPTION = "Widgets for GPlates Data Mining."

BACKGROUND = "#FFB7B1"

ICON = "icons/compute_birth_attribute.png" #FIXME:

PRIORITY = 2
