[![Build
Status](https://travis-ci.org/csdms/bmi_tester.svg?branch=master)](https://travis-ci.org/csdms/bmi_tester)
[![Documentation
Status](https://readthedocs.org/projects/bmi-tester/badge/?version=latest)](http://bmi-tester.readthedocs.io/en/latest/?badge=latest)
[![Coverage
Status](https://coveralls.io/repos/github/csdms/bmi_tester/badge.svg?branch=master)](https://coveralls.io/github/csdms/bmi_tester?branch=master)
[![Anaconda-Server
Badge](https://anaconda.org/csdms/bmi_tester/badges/version.svg)](https://anaconda.org/csdms/bmi_tester)
[![Anaconda-Server
Badge](https://anaconda.org/csdms/bmi_tester/badges/installer/conda.svg)](https://conda.anaconda.org/csdms)
[![Anaconda-Server
Badge](https://anaconda.org/csdms/bmi_tester/badges/downloads.svg)](https://anaconda.org/csdms/bmi_tester)

bmi-tester
==========

Test a Python implementation of the Basic Model Interface.

Links
-----

*  [Source code](http://github.com/csdms/bmi_tester): The
   *bmi_tester* source code repository.
*  [Documentation](http://bmi-tester.readthedocs.io/): User
   documentation for *bmi_tester*
*  [Get](http://bmi-tester.readthedocs.io/en/latest/getting.html):
   Installation instructions
