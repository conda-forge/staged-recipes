var searchData=
[
  ['typed_20macros',['Typed Macros',['../group__typed.html',1,'']]]
];
