library(testthat)
library(sdmpredictors)

options(timeout = 600)

test_check("sdmpredictors")