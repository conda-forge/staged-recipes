get_sysdata <- function() {
  data <- .data
  return(data)
}