from __future__ import absolute_import
from nlpaug.model.word_embs.word_embeddings import *
from nlpaug.model.word_embs.glove import *
from nlpaug.model.word_embs.word2vec import *
from nlpaug.model.word_embs.fasttext import *