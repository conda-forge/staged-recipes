class Spectrogram:
    def manipulate(self, data):
        raise NotImplementedError
