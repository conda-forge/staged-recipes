class Audio:
    def manipulate(self, data):
        raise NotImplementedError
