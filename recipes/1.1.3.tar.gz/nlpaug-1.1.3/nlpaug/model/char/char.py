class Character:
    def __init__(self, cache=True):
        self.cache = cache
