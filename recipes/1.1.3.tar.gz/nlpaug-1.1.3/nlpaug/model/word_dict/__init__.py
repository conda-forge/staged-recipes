from __future__ import absolute_import
from nlpaug.model.word_dict.word_dictionary import *
from nlpaug.model.word_dict.spelling import *
from nlpaug.model.word_dict.wordnet import *
from nlpaug.model.word_dict.ppdb import *
