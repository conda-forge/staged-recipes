from __future__ import absolute_import
from nlpaug.augmenter.spectrogram.spectrogram_augmenter import *
from nlpaug.augmenter.spectrogram.frequency_masking import *
from nlpaug.augmenter.spectrogram.time_masking import *
from nlpaug.augmenter.spectrogram.loudness import *