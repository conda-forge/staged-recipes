from __future__ import absolute_import
from nlpaug.augmenter.char.char_augmenter import *
from nlpaug.augmenter.char.ocr import *
from nlpaug.augmenter.char.random import *
from nlpaug.augmenter.char.keyboard import *
