

class Augment:
    def __init__(self, pos, original, new):
        self.pos = pos
        self.original = original
        self.new = new
