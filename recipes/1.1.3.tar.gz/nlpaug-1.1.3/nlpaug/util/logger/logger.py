import logging


logger = logging.getLogger("nlpaug-general")

class Logger:
	@staticmethod
	def log():
		return logger