nlpaug.augmenter.sentence\.context_word_embs_sentence
=====================================================

.. automodule:: nlpaug.augmenter.sentence.context_word_embs_sentence
    :members:
    :inherited-members:
    :show-inheritance:
