nlpaug.augmenter.sentence\.abst_summ
=====================================================

.. automodule:: nlpaug.augmenter.sentence.abst_summ
    :members:
    :inherited-members:
    :show-inheritance:
