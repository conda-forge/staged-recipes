nlpaug.augmenter.word\.split
============================

.. automodule:: nlpaug.augmenter.word.split
    :members:
    :inherited-members:
    :show-inheritance:
