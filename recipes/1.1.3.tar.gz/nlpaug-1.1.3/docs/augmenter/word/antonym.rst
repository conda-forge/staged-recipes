nlpaug.augmenter.word\.antonym
==============================

.. automodule:: nlpaug.augmenter.word.antonym
    :members:
    :inherited-members:
    :show-inheritance:
