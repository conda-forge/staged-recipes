nlpaug.augmenter.word\.tfidf
================================

.. automodule:: nlpaug.augmenter.word.tfidf
    :members:
    :inherited-members:
    :show-inheritance:
