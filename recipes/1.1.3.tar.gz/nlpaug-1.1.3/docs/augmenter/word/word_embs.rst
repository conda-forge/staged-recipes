nlpaug.augmenter.word\.word_embs
================================

.. automodule:: nlpaug.augmenter.word.word_embs
    :members:
    :inherited-members:
    :show-inheritance:
