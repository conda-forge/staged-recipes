Word Augmenter
==============

.. toctree::
    :maxdepth: 6

    ./antonym
    ./back_translation
    ./context_word_embs
    ./random
    ./spelling
    ./split
    ./synonym
    ./tfidf
    ./word_embs
