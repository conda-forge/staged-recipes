nlpaug.augmenter.word\.back_translation
========================================

.. automodule:: nlpaug.augmenter.word.back_translation
    :members:
    :inherited-members:
    :show-inheritance:
