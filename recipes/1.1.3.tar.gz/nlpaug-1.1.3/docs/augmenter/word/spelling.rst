nlpaug.augmenter.word\.spelling
================================

.. automodule:: nlpaug.augmenter.word.spelling
    :members:
    :inherited-members:
    :show-inheritance:
