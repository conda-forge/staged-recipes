nlpaug.augmenter.word\.synonym
==============================

.. automodule:: nlpaug.augmenter.word.synonym
    :members:
    :inherited-members:
    :show-inheritance:
