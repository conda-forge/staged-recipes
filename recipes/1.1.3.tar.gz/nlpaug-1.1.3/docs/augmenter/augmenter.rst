Augmenter
=========

.. toctree::
    :maxdepth: 6

    ./audio/audio
    ./char/char
    ./sentence/sentence
    ./spectrogram/spectrogram
    ./word/word