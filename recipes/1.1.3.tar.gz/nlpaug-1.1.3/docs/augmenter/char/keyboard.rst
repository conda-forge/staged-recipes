nlpaug.augmenter.char\.keyboard
===============================

.. automodule:: nlpaug.augmenter.char.keyboard
    :members:
    :inherited-members:
    :show-inheritance:
