nlpaug.augmenter.char\.ocr
==============================================

.. automodule:: nlpaug.augmenter.char.ocr
    :members:
    :inherited-members:
    :show-inheritance:
