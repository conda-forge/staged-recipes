Character Augmenter
===================

.. toctree::
    :maxdepth: 6

    ./keyboard
    ./ocr
    ./random