nlpaug.augmenter.audio\.speed
==============================================

.. automodule:: nlpaug.augmenter.audio.speed
    :members:
    :inherited-members:
    :show-inheritance:
