nlpaug.augmenter.audio\.pitch
==============================================

.. automodule:: nlpaug.augmenter.audio.pitch
    :members:
    :inherited-members:
    :show-inheritance:
