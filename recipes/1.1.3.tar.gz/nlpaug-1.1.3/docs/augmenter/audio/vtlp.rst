nlpaug.augmenter.audio\.vtlp
============================

.. automodule:: nlpaug.augmenter.audio.vtlp
    :members:
    :inherited-members:
    :show-inheritance:
