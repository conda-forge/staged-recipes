Audio Augmenter
===============

.. toctree::
    :maxdepth: 6

    ./crop
    ./loudness
    ./mask
    ./noise
    ./pitch
    ./shift
    ./speed
    ./vtlp