nlpaug.augmenter.audio\.noise
==============================================

.. automodule:: nlpaug.augmenter.audio.noise
    :members:
    :inherited-members:
    :show-inheritance:
