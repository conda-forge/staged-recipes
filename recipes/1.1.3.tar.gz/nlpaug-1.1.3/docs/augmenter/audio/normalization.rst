nlpaug.augmenter.audio\.normalization
==============================================

.. automodule:: nlpaug.augmenter.audio.normalization
    :members:
    :inherited-members:
    :show-inheritance:
