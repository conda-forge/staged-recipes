nlpaug.augmenter.audio\.shift
==============================================

.. automodule:: nlpaug.augmenter.audio.shift
    :members:
    :inherited-members:
    :show-inheritance:
