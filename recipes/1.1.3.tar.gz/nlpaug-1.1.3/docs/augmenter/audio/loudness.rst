nlpaug.augmenter.audio\.loudness
==============================================

.. automodule:: nlpaug.augmenter.audio.loudness
    :members:
    :inherited-members:
    :show-inheritance:
