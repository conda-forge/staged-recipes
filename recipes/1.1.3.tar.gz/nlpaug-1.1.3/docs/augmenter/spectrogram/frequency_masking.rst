nlpaug.augmenter.spectrogram\.frequency_masking
===============================================

.. automodule:: nlpaug.augmenter.spectrogram.frequency_masking
    :members:
    :inherited-members:
    :show-inheritance:
