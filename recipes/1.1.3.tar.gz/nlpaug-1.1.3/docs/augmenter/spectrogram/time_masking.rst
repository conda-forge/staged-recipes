nlpaug.augmenter.spectrogram\.time_masking
==========================================

.. automodule:: nlpaug.augmenter.spectrogram.time_masking
    :members:
    :inherited-members:
    :show-inheritance:
