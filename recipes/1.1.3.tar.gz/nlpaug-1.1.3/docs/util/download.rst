nlpaug.util.file\.download
==========================================

.. automodule:: nlpaug.util.file.download
    :members:
    :show-inheritance:
